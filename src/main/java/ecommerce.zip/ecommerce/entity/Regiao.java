package ecommerce.entity;

public enum Regiao
{
	SUDESTE, SUL, CENTRO_OESTE, NORDESTE, NORTE
}
