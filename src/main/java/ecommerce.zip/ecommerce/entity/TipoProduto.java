package ecommerce.entity;

public enum TipoProduto
{
	ELETRONICO, ROUPA, ALIMENTO, LIVRO, MOVEL;
}
