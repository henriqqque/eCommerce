package ecommerce.entity;

public enum TipoCliente
{
	BRONZE, PRATA, OURO
}
