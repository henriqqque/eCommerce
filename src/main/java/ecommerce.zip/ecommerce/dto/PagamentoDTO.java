package ecommerce.dto;

public record PagamentoDTO(Boolean autorizado, Long transacaoId)
{
}
